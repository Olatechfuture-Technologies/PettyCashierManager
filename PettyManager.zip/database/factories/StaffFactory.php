<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;
use App\Models\Staff;

class StaffFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Staff::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'firstName' => $this->faker->word,
            'lastName' => $this->faker->word,
            'phoneN0' => $this->faker->word,
            'email' => $this->faker->safeEmail,
            'username' => $this->faker->userName,
            'password' => $this->faker->password,
            'deleted_at' => $this->faker->dateTime(),
        ];
    }
}
