<?php

namespace App\Http\Livewire;

use Livewire\Component;

class DashboardSummary extends Component
{
    public function render()
    {
        return view('livewire.dashboard-summary');
    }
}
