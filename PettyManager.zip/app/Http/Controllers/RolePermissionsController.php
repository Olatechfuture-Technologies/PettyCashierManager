<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RolePermissionsController extends Controller
{
    public function index()
    {
        # code...
    }
}
